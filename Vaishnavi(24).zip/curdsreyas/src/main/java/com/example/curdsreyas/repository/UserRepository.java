package com.example.curdsreyas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.curdsreyas.entity.PlaceUser;

public interface UserRepository extends JpaRepository<PlaceUser,Integer>{

}
 