package com.example.curdsreyas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.curdsreyas.entity.PlaceUser;
import com.example.curdsreyas.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	public UserService userv;
	
	@PostMapping("/adduser")
	public PlaceUser regUser(@RequestBody PlaceUser u) {
		return userv.addUser(u);
	}
	
	
	@GetMapping("/getuser")
	public List<PlaceUser> getUser() {
		return userv.getPlaceUser();
	}
	
	@DeleteMapping("/deleteuser/{id}")
	public void deleteUser(@PathVariable Integer id) {
		userv.deleteUser(id);
	}
	
	
	@PutMapping("/updateuser")
	public PlaceUser updateUser(@RequestBody PlaceUser u) {
		 return userv.updateUser(u);
	}
	
	

}

