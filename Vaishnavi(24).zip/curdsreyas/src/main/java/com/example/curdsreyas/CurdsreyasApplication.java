package com.example.curdsreyas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurdsreyasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurdsreyasApplication.class, args);
	}

}
