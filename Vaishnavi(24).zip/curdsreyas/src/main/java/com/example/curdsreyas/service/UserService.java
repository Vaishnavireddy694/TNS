package com.example.curdsreyas.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.curdsreyas.entity.PlaceUser;
import com.example.curdsreyas.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	public UserRepository urepo;
	
	//post data
	public PlaceUser addUser(PlaceUser u) {
		return urepo.save(u);
	}	
	
	//get data 
	public List<PlaceUser> getPlaceUser() {
		return urepo.findAll();
	}
	
	
	//delete data
	public void deleteUser(int id) {
		 urepo.deleteById(id);;
	}
	
	
	//update data
	public PlaceUser updateUser(PlaceUser u) {
		
		Integer uid=u.getUid();
		PlaceUser user1=urepo.findById(uid).get();
		user1.setName(u.getName());
		user1.setType(u.getType());
		user1.setPassword(u.getPassword());
		return urepo.save(user1);
	}
	
	
	

}
