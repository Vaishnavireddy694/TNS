package com.example.curdsreyas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurdsreyasApplicationTests {

	@Test
	void contextLoads() {
	}

}
